import ultralytics
ultralytics.checks()